import edu.princeton.cs.algs4.BinaryStdIn;
import edu.princeton.cs.algs4.BinaryStdOut;
import edu.princeton.cs.algs4.StdOut;

/**
 * Created by Zhao on 2015-12-17.
 */
public class MoveToFront {
    // apply move-to-front encoding, reading from standard input and writing to standard output
    public static void encode()
    {
        char[] ascii = new char[256];
        for (char code = 0; code < 256; code++ )
        {
            ascii[code]=code;
        }
        String s = BinaryStdIn.readString();
        int w = s.length();
        char[] output = new char[w];

        for (int i = 0; i < w; i++)
        {
            char c =  s.charAt(i);
            for (char j = 0; j < 256; j++)
            {
                if (ascii[j] == c)
                {

                    output[i] = j;
                    if (j > 0) {
                        System.arraycopy(ascii, 0, ascii, 1, j);
                        ascii[0] = c;

                        //ascii.deleteCharAt(j);
                        //ascii.insert(0, c);
                    }
                }
            }
        }
        for (char c : output)
        {
            BinaryStdOut.write(c);
        }
        BinaryStdOut.flush();
    }

    // apply move-to-front decoding, reading from standard input and writing to standard output
    public static void decode()
    {
        char[] ascii = new char[256];
        for (char code = 0; code < 256; code++ )
        {
            ascii[code]=code;
        }
        String s = BinaryStdIn.readString();
        int w = s.length();
        StdOut.println(w);
        char[] output = new char[w];
        for (int i = 0; i < w; i++)
        {
            char c =  s.charAt(i);
            char h = ascii[c];
            //StdOut.print(h);

            //BinaryStdOut.write(h);
            output[i] = h;
            if (c > 0) {

                System.arraycopy(ascii, 0, ascii, 1, c);
                ascii[0] = h;
                //ascii.deleteCharAt(c);
                //ascii.insert(0, h);
            }
        }
        for (char c : output)
        {
            BinaryStdOut.write(c);
        }

        BinaryStdOut.flush();

    }

    // if args[0] is '-', apply move-to-front encoding
    // if args[0] is '+', apply move-to-front decoding
    public static void main(String[] args)
    {
        if (args[0].equals("-"))
        {
            encode();
        }
        if (args[0].equals("+"))
        {
            decode();
        }
    }
}
