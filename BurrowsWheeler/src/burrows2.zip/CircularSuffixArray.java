import edu.princeton.cs.algs4.StdOut;

/**
 * Created by Zhao on 2015-12-17.
 */
public class CircularSuffixArray {
    private String original;
    private suffix[] sufficesArray;
    private int suffixLen;

    private class suffix
    {
        public int start;
        //public int end;
        public int order;
        public char suffixCharAt(int i)
        {
            int j = (start + i) % suffixLen;
            return original.charAt(j);
        }
    }

    // Helper region

    private void genSuffices()
    {
        for (int i = 0; i < suffixLen; i++)
        {
            sufficesArray[i] = new suffix();
            sufficesArray[i].start = i;
            sufficesArray[i].order = i;
        }
    }

    private void suffixLSD()
    {
        int N = suffixLen;
        int R = 256;   // extend ASCII alphabet size
        suffix[] aux = new suffix[N];

        for (int d = N-1; d >= 0; d--) {
            // sort by key-indexed counting on dth character

            // compute frequency counts
            int[] count = new int[R+1];
            for (int i = 0; i < N; i++)
                count[sufficesArray[i].suffixCharAt(d) + 1]++;

            // compute cumulates
            for (int r = 0; r < R; r++)
                count[r+1] += count[r];

            // move data
            for (int i = 0; i < N; i++)
                aux[count[sufficesArray[i].suffixCharAt(d)]++] = sufficesArray[i];

            // copy back
            for (int i = 0; i < N; i++)
                sufficesArray[i] = aux[i];
        }
    }

    private void suffixMSD()
    {

    }
    private static final int R             = 256;   // extended ASCII alphabet size
    private static final int CUTOFF        =  15;   // cutoff to insertion sort
    private static void sort(suffix[] a) {
        int N = a.length;
        suffix[] aux = new suffix[N];
        sort(a, 0, N-1, 0, aux);
    }

    // return dth character of s, -1 if d = length of string
    private static int charAt(suffix s, int d) {
        return s.suffixCharAt(d);
    }

    // sort from a[lo] to a[hi], starting at the dth character
    private static void sort(suffix[] a, int lo, int hi, int d, suffix[] aux) {

        // cutoff to insertion sort for small subarrays
        if (hi <= lo + CUTOFF) {
            insertion(a, lo, hi, d);
            return;
        }

        // compute frequency counts
        int[] count = new int[R+2];
        for (int i = lo; i <= hi; i++) {
            int c = charAt(a[i], d);
            count[c+2]++;
        }

        // transform counts to indicies
        for (int r = 0; r < R+1; r++)
            count[r+1] += count[r];

        // distribute
        for (int i = lo; i <= hi; i++) {
            int c = charAt(a[i], d);
            aux[count[c+1]++] = a[i];
        }

        // copy back
        for (int i = lo; i <= hi; i++)
            a[i] = aux[i - lo];


        // recursively sort for each character (excludes sentinel -1)
        for (int r = 0; r < R; r++)
            sort(a, lo + count[r], lo + count[r+1] - 1, d+1, aux);
    }


    // insertion sort a[lo..hi], starting at dth character
    private static void insertion(suffix[] a, int lo, int hi, int d) {
        for (int i = lo; i <= hi; i++)
            for (int j = i; j > lo && less(a[j], a[j-1], d, a.length); j--)
                exch(a, j, j-1);
    }

    // exchange a[i] and a[j]
    private static void exch(suffix[] a, int i, int j) {
        suffix temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }

    // is v less than w, starting at character d
    private static boolean less(suffix v, suffix w, int d,int len) {
        // assert v.substring(0, d).equals(w.substring(0, d));
        for (int i = d; i < len; i++) {
            if (v.suffixCharAt(i) < w.suffixCharAt(i)) return true;
            if (v.suffixCharAt(i) > w.suffixCharAt(i)) return false;
        }
        return true;
    }





    // Helper region ends

    public CircularSuffixArray(String s)  // circular suffix array of s
    {
        if (s ==null)
            throw new NullPointerException();
        original = s;
        suffixLen = original.length();
        sufficesArray = new suffix[suffixLen];
        genSuffices();
        //suffixLSD();
        sort(sufficesArray);
    }

    public int length()                   // length of s
    {
        return suffixLen;
    }
    public int index(int i)               // returns index of ith sorted suffix
    {
        if (i<0 || i >= suffixLen)
            throw new IndexOutOfBoundsException();
        return sufficesArray[i].order;
    }
    public static void main(String[] args)// unit testing of the methods (optional)
    {
        CircularSuffixArray CSA = new CircularSuffixArray("ABRACADABRA!");
        for (int i = 0; i < CSA.length(); i++)
        {
            StdOut.println("");
            for (int j = 0; j < CSA.length(); j++)
            {
                StdOut.print(CSA.sufficesArray[i].suffixCharAt(j));
            }
            StdOut.print("    index: " + CSA.index(i) );
        }
    }
}
