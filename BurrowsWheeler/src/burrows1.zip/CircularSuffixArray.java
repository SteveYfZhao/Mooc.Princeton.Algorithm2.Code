import edu.princeton.cs.algs4.StdOut;

/**
 * Created by Zhao on 2015-12-17.
 */
public class CircularSuffixArray {
    private String original;
    private suffix[] sufficesArray;
    private int suffixLen;

    private class suffix
    {
        public int start;
        //public int end;
        public int order;
        public char suffixCharAt(int i)
        {
            int j = (start + i) % suffixLen;
            return original.charAt(j);
        }
    }

    // Helper region

    private void genSuffices()
    {
        for (int i = 0; i < suffixLen; i++)
        {
            sufficesArray[i] = new suffix();
            sufficesArray[i].start = i;
            sufficesArray[i].order = i;
        }
    }

    private void suffixLSD()
    {
        int N = suffixLen;
        int R = 256;   // extend ASCII alphabet size
        suffix[] aux = new suffix[N];

        for (int d = N-1; d >= 0; d--) {
            // sort by key-indexed counting on dth character

            // compute frequency counts
            int[] count = new int[R+1];
            for (int i = 0; i < N; i++)
                count[sufficesArray[i].suffixCharAt(d) + 1]++;

            // compute cumulates
            for (int r = 0; r < R; r++)
                count[r+1] += count[r];

            // move data
            for (int i = 0; i < N; i++)
                aux[count[sufficesArray[i].suffixCharAt(d)]++] = sufficesArray[i];

            // copy back
            for (int i = 0; i < N; i++)
                sufficesArray[i] = aux[i];
        }
    }


    // Helper region ends

    public CircularSuffixArray(String s)  // circular suffix array of s
    {
        if (s ==null)
            throw new NullPointerException();
        original = s;
        suffixLen = original.length();
        sufficesArray = new suffix[suffixLen];
        genSuffices();
        suffixLSD();
    }

    public int length()                   // length of s
    {
        return suffixLen;
    }
    public int index(int i)               // returns index of ith sorted suffix
    {
        if (i<0 || i >= suffixLen)
            throw new IndexOutOfBoundsException();
        return sufficesArray[i].order;
    }
    public static void main(String[] args)// unit testing of the methods (optional)
    {
        CircularSuffixArray CSA = new CircularSuffixArray("ABRACADABRA!");
        for (int i = 0; i < CSA.length(); i++)
        {
            StdOut.println("");
            for (int j = 0; j < CSA.length(); j++)
            {
                StdOut.print(CSA.sufficesArray[i].suffixCharAt(j));
            }
            StdOut.print("    index: " + CSA.index(i) );
        }
    }
}
